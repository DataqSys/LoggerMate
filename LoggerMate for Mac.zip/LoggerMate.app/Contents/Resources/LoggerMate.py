"""
LoggerMate App for Datalogger Configuration

Version:   3.0
Date:      5/10/2019
Author:    Bryn Morgan @ bryn.o.morgan@gmail.com
"""

import wx

import wx.lib.popupctl as pop
import threading
import os
import serial
import serial.tools.list_ports

#----------------------------------------------------------------------

def getSerialPorts():
    ports = []
        
    for i in serial.tools.list_ports.comports(include_links=False):
        ports.append(i.device)

    return ports

class Frame(wx.Frame):
    def __init__(self, title):
        self.ports = getSerialPorts()
        self.ports.sort()

        self.port = None

        self.D = 0
        self.M = 0
        self.S = 0
        self.A = 0
        self.N = 0
        self.T = 0
        self.dataNum = 0
        self.connected = False
        self.dataCleared = False

        wx.Frame.__init__(self, None, title = title, pos = (150, 150), size = (590, 520))

        #menuBar = wx.MenuBar()
        #menu = wx.Menu()
        #m_exit = menu.Append(wx.ID_EXIT, "E&xit\tAlt-X", "Close window and exit program.")
        #menuBar.Append(menu, "&File")
        #self.SetMenuBar(menuBar)
        
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetFieldsCount(3)
        self.statusbar.SetStatusWidths([-3, -2, -3])
        
        self.statusbar.SetStatusText("Port Not Set", 0)
        self.statusbar.SetStatusText("Not Connected", 1)        

        self.panel = wx.Panel(self)

        self.selCOMPortButton = wx.Button(self.panel, label = "Set COM Port")
        self.selCOMPortButton.Bind(wx.EVT_BUTTON, self.OnSelCOMPortButton)
        
        self.connectButton = wx.Button(self.panel, label = "Connect")
        self.connectButton.Bind(wx.EVT_BUTTON, self.OnConnectButton)

        self.downloadButton = wx.Button(self.panel, label = "Download Data")
        self.downloadButton.Bind(wx.EVT_BUTTON, self.OnDownloadButton)

        self.eraseButton = wx.Button(self.panel, label = "Erase Data")
        self.eraseButton.Bind(wx.EVT_BUTTON, self.OnEraseButton)

        self.deviceIDText = wx.StaticText(self.panel, label = "Device ID")
        self.deviceIDSpin = wx.SpinCtrl(self.panel)
        self.deviceIDSpin.SetRange(1, 255)

        self.baseClockText = wx.StaticText(self.panel, label = "Base clock time")       
        self.baseClockSpin = wx.SpinCtrl(self.panel)
        self.baseClockSpin.SetRange(1, 255)
        self.baseClockSpin.Bind(wx.EVT_SPINCTRL, self.UpdateInfo)
        self.baseClockUnitsChoice = wx.Choice(self.panel, choices = ["second(s)", "minute(s)"])
        self.baseClockUnitsChoice.SetSelection(self.M)

        self.activityCheck = wx.CheckBox(self.panel, label = "")
        self.activityCheck.SetValue(True)
        self.activityCheck.Bind(wx.EVT_CHECKBOX, self.OnActivityCheck) 
        self.activityText = wx.StaticText(self.panel, label = "Activity sample every")
        self.activitySpin = wx.SpinCtrl(self.panel)
        self.activitySpin.SetRange(1, 255)
        self.activitySpin.Bind(wx.EVT_SPINCTRL, self.UpdateInfo)
        self.activityUnitsText = wx.StaticText(self.panel, label = "clock(s)")       

        self.averageCheck = wx.CheckBox(self.panel, label = "")
        self.averageCheck.SetValue(True)
        self.averageCheck.Bind(wx.EVT_CHECKBOX, self.OnAverageCheck) 
        self.averageText = wx.StaticText(self.panel, label = "Average activity every")       
        self.averageSpin = wx.SpinCtrl(self.panel)
        self.averageSpin.SetRange(2, 255)
        self.averageSpin.Bind(wx.EVT_SPINCTRL, self.UpdateInfo)
        self.averageUnitsText = wx.StaticText(self.panel, label = "samples")

        self.tempCheck = wx.CheckBox(self.panel, label = "")
        self.tempCheck.SetValue(True)
        self.tempCheck.Bind(wx.EVT_CHECKBOX, self.OnTempCheck) 
        self.tempText = wx.StaticText(self.panel, label = "Temp sample every")       
        self.tempSpin = wx.SpinCtrl(self.panel)
        self.tempSpin.SetRange(1,255)
        self.tempSpin.Bind(wx.EVT_SPINCTRL, self.UpdateInfo)
        self.tempUnitsText = wx.StaticText(self.panel, label = "clock(s)")
        
        self.activityInfoImg = wx.StaticBitmap(self.panel, -1, wx.Bitmap("act_logged.png", wx.BITMAP_TYPE_ANY))
        self.activityInfoText = wx.StaticText(self.panel, label = "")
        self.tempInfoImg = wx.StaticBitmap(self.panel, -1, wx.Bitmap("temp_logged.png", wx.BITMAP_TYPE_ANY))
        self.tempInfoText = wx.StaticText(self.panel, label = "")

        font = wx.Font(12, wx.DEFAULT, wx.ITALIC, wx.NORMAL)
        self.activityInfoText.SetFont(font)
        self.tempInfoText.SetFont(font)
        self.UpdateInfo()

        self.uploadButton = wx.Button(self.panel, label = "Upload Config")
        self.uploadButton.SetBitmap(wx.Bitmap("upload_icon_32.png", wx.BITMAP_TYPE_ANY), wx.RIGHT)
        self.uploadButton.SetFont(font = wx.Font(12, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD))
        self.uploadButton.Bind(wx.EVT_BUTTON, self.OnUploadButton)

        self.baseClockUnitsChoice.Bind(wx.EVT_CHOICE, self.UpdateInfo)

        mainSizer = wx.FlexGridSizer(cols = 1, hgap = 5, vgap = 5)
        topButtonsSizer = wx.BoxSizer(wx.HORIZONTAL)
        configAreaSizer = wx.FlexGridSizer(cols = 4, hgap = 5, vgap = 5)
        activityOutputSizer = wx.BoxSizer(wx.HORIZONTAL)
        tempOutputSizer = wx.BoxSizer(wx.HORIZONTAL)
        uploadSizer = wx.BoxSizer(wx.HORIZONTAL)

        ## Add top buttons to horizontal sizer
        topButtonsSizer.Add(self.selCOMPortButton, 1, wx.ALL | wx.EXPAND, 5)
        topButtonsSizer.Add(self.connectButton, 1, wx.ALL | wx.EXPAND, 5)
        topButtonsSizer.Add(self.downloadButton, 1, wx.ALL | wx.EXPAND, 5)
        topButtonsSizer.Add(self.eraseButton, 1, wx.ALL | wx.EXPAND, 5)

        ## Add config items to grid sizer
        configAreaSizer.Add((0, 0), 1, wx.EXPAND)
        configAreaSizer.Add(self.deviceIDText, 1, wx.ALL | wx.ALIGN_CENTRE_VERTICAL, 5)
        configAreaSizer.Add(self.deviceIDSpin, 1, wx.ALL | wx.EXPAND, 5)
        configAreaSizer.Add((20, 20), 1, wx.EXPAND)

        configAreaSizer.Add((0, 0), 1, wx.EXPAND)
        configAreaSizer.Add(self.baseClockText, 1, wx.ALL | wx.ALIGN_CENTRE_VERTICAL, 5)
        configAreaSizer.Add(self.baseClockSpin, 1, wx.ALL | wx.EXPAND, 5)
        configAreaSizer.Add(self.baseClockUnitsChoice, 1, wx.RIGHT | wx.ALIGN_LEFT | wx.ALIGN_CENTRE_VERTICAL, 5)

        configAreaSizer.Add(self.activityCheck, 1, wx.ALL | wx.ALIGN_CENTRE, 5)
        configAreaSizer.Add(self.activityText, 1, wx.ALL | wx.ALIGN_CENTRE_VERTICAL, 5)
        configAreaSizer.Add(self.activitySpin, 1, wx.ALL | wx.EXPAND, 5)
        configAreaSizer.Add(self.activityUnitsText, 1, wx.ALIGN_LEFT | wx.ALIGN_CENTRE_VERTICAL, 5)

        configAreaSizer.Add(self.averageCheck, 1, wx.ALL | wx.ALIGN_CENTRE, 5)
        configAreaSizer.Add(self.averageText, 1, wx.ALL | wx.ALIGN_CENTRE_VERTICAL, 5)
        configAreaSizer.Add(self.averageSpin, 1, wx.ALL | wx.EXPAND, 5)
        configAreaSizer.Add(self.averageUnitsText, 1, wx.ALIGN_LEFT | wx.ALIGN_CENTRE_VERTICAL, 5)

        configAreaSizer.Add(self.tempCheck, 1, wx.ALL | wx.ALIGN_CENTRE, 5)
        configAreaSizer.Add(self.tempText, 1, wx.ALL | wx.ALIGN_CENTRE_VERTICAL, 5)
        configAreaSizer.Add(self.tempSpin, 1, wx.ALL | wx.EXPAND, 5)
        configAreaSizer.Add(self.tempUnitsText, 1, wx.ALIGN_LEFT | wx.ALIGN_CENTRE_VERTICAL, 5)

        configAreaSizer.AddGrowableCol(2, 1)

        ## Add output info to sizers
        activityOutputSizer.Add(self.activityInfoImg, 0, wx.LEFT | wx.ALIGN_CENTRE, 5)
        activityOutputSizer.Add(self.activityInfoText, 0, wx.ALL | wx.ALIGN_CENTRE, 5)
        tempOutputSizer.Add(self.tempInfoImg, 0, wx.LEFT | wx.ALIGN_CENTRE, 5)
        tempOutputSizer.Add(self.tempInfoText, 0, wx.ALL | wx.ALIGN_CENTRE, 5)

        
        
        mainSizer.Add(topButtonsSizer, 1, wx.LEFT | wx.TOP | wx.RIGHT | wx.EXPAND, 5)
        mainSizer.Add(wx.StaticLine(self.panel), 1, wx.LEFT | wx.RIGHT | wx.EXPAND, 5)
        mainSizer.Add(configAreaSizer, 1, wx.LEFT | wx.RIGHT | wx.EXPAND, 5)
        mainSizer.Add(wx.StaticLine(self.panel), 1, wx.LEFT | wx.RIGHT | wx.EXPAND, 5)
        mainSizer.Add(activityOutputSizer, 0, wx.LEFT | wx.TOP | wx.EXPAND, 5)
        mainSizer.Add(tempOutputSizer, 0, wx.LEFT | wx.CENTRE, 5)
        mainSizer.Add(self.uploadButton, 0, wx.ALL | wx.ALIGN_CENTRE, 5)

        mainSizer.AddGrowableCol(0, 1)

        self.panel.SetSizer(mainSizer)
        mainSizer.Fit(self)
        

    def GetConfig(self, ser):
        c = ""

        chars = []

        ser.open()

        i = 0

        while (c != b'+'):
            c = ser.read()
            chars.append(c.decode('utf-8'))
            i += 1
        else:
            dialog = wx.MessageDialog(self.panel, "Logger communication timeout.", caption = "Error", style = wx.OK | wx.ICON_EXCLAMATION)
            dialog.ShowModal()
            dialog.Destroy()            

        ser.close()

        return chars
            
    def OnUploadButton(self, event):
        ser = self.GetCOMPort()
        
        if (ser and self.GetDeviceConnected()):
            if (self.dataNum == 0):
                d = self.deviceIDSpin.GetValue()
                m = self.baseClockUnitsChoice.GetSelection()
                s = self.baseClockSpin.GetValue()
                a = self.activitySpin.GetValue()
                n = self.averageSpin.GetValue()
                t = self.tempSpin.GetValue()
                
                if (not(self.activityCheck.GetValue())):
                    a = 0
                if (not(self.averageCheck.GetValue())):
                    n = 0
                if (not(self.tempCheck.GetValue())):
                    t = 0

                ser.open()
                ser.write(("D" + str(d) +
                           "M" + str(m) +
                           "S" + str(s) +
                           "A" + str(a) +
                           "N" + str(n) +
                           "T" + str(t) +
                           "+").encode('utf-8'))

                c = ""
                chars = []

                i = 0

                for i in range(40):
                    c = ser.read().decode('utf-8')
                    chars.append(c)

                    if (c == '+'):
                        break

                ser.close()

                if (c != '+'):
                    dialog = wx.MessageDialog(self.panel, "Logger communication timeout.", caption = "Error", style = wx.OK | wx.ICON_EXCLAMATION)
                    dialog.ShowModal()
                    dialog.Destroy()
                else:
                    self.UpdateConfig(chars)

                    dialog = wx.MessageDialog(self.panel, "Config uploaded!", caption = "Uploaded", style = wx.OK)
                    dialog.ShowModal()
                    dialog.Destroy()
            else:
                dialog = wx.MessageDialog(self.panel, "Please erase the memory before upload.", caption = "Error", style = wx.OK | wx.ICON_EXCLAMATION)
                dialog.ShowModal()
                dialog.Destroy()

    def UpdateInfo(self, event = None):
        """ Can be called by event handler or by other parts of code to update the info. """
        unitsSel = self.baseClockUnitsChoice.GetString(self.baseClockUnitsChoice.GetSelection())

        if (not(self.activityCheck.GetValue())):
            self.activityInfoText.SetLabel("Activity will NOT be logged")
            self.activityInfoImg.SetBitmap(wx.Bitmap("act_not_logged.png", wx.BITMAP_TYPE_ANY))
            
        else:
            self.activityInfoImg.SetBitmap(wx.Bitmap("act_logged.png", wx.BITMAP_TYPE_ANY))
            if (not(self.averageCheck.GetValue())):
                self.activityInfoText.SetLabel("Activity will be logged every " + str(self.activitySpin.GetValue() * self.baseClockSpin.GetValue()) + " " + unitsSel)
            else:
                self.activityInfoText.SetLabel("Activity will be logged every " + str(self.activitySpin.GetValue() * self.baseClockSpin.GetValue() *
                                               self.averageSpin.GetValue()) + " " + unitsSel)

        if (not(self.tempCheck.GetValue())):
            self.tempInfoText.SetLabel("Temperature will NOT be logged")
            self.tempInfoImg.SetBitmap(wx.Bitmap("temp_not_logged.png", wx.BITMAP_TYPE_ANY))
        else:
            self.tempInfoImg.SetBitmap(wx.Bitmap("temp_logged.png", wx.BITMAP_TYPE_ANY))
            self.tempInfoText.SetLabel("Temperature will be logged every " + str(self.tempSpin.GetValue() * self.baseClockSpin.GetValue()) + " " + unitsSel)
                
    def OnActivityCheck(self, event):
        if (self.activityCheck.GetValue()):
            self.averageCheck.Enable(True)
            self.activityText.Enable(True)
            self.activitySpin.Enable(True)
            self.activityUnitsText.Enable(True)
        else:
            self.activityText.Enable(False)
            self.activitySpin.Enable(False)
            self.activityUnitsText.Enable(False)
            
            self.averageCheck.SetValue(False)
            self.averageCheck.Enable(False)
            self.averageText.Enable(False)
            self.averageSpin.Enable(False)
            self.averageUnitsText.Enable(False)

        self.UpdateInfo()

    def OnAverageCheck(self, event):
        if (self.averageCheck.GetValue()):
            self.averageText.Enable(True)
            self.averageSpin.Enable(True)
            self.averageUnitsText.Enable(True)
        else:
            self.averageText.Enable(False)
            self.averageSpin.Enable(False)
            self.averageUnitsText.Enable(False)

        self.UpdateInfo()

    def OnTempCheck(self, event):
        if (self.tempCheck.GetValue()):
            self.tempText.Enable(True)
            self.tempSpin.Enable(True)
            self.tempUnitsText.Enable(True)
        else:
            self.tempText.Enable(False)
            self.tempSpin.Enable(False)
            self.tempUnitsText.Enable(False)

        self.UpdateInfo()

    def OnSelCOMPortButton(self, event):

        self.ports = getSerialPorts()
        self.ports.sort()

        dialog = wx.SingleChoiceDialog(self, 'COM Ports:', 'Select COM Port',
                self.ports,
                wx.CHOICEDLG_STYLE | wx.STAY_ON_TOP
                )
        
        if (dialog.ShowModal() == wx.ID_OK):
             self.COMSelUpdated(dialog.GetSelection())

        dialog.Destroy()

    def GetCOMPort(self):
        if(self.port):
            try:
                ser = serial.Serial(self.port, 250000, timeout = 0.01)
                ser.close()
                return ser
            except:
                self.ResetConfig()
                dialog = wx.MessageDialog(self.panel, "COM Port in use.", caption = "Error Opening COM Port", style = wx.OK | wx.ICON_EXCLAMATION)
                dialog.ShowModal()
                dialog.Destroy()
                return 0
        else:
            self.ResetConfig()
            dialog = wx.MessageDialog(self.panel, "Please select a COM port.", caption = "No COM Port Selected", style = wx.OK | wx.ICON_EXCLAMATION)
            dialog.ShowModal()
            dialog.Destroy()
            return 0

    def GetDeviceConnected(self):
        if (not(self.connected)):
            dialog = wx.MessageDialog(self.panel, "Please connect to the device first.", caption = "Error", style = wx.OK | wx.ICON_EXCLAMATION)
            dialog.ShowModal()
            dialog.Destroy()

            return 0
        else:
            return 1

    def GetDatalogger(self):
        ser = self.GetCOMPort()
        
        if ser:
            ser.open()
            ser.write(b'+')
            
            c = ""

            chars = []

            i = 0

            for i in range(40):
                c = ser.read().decode('utf-8')
                chars.append(c)

                if (c == '+'):
                    break

            ser.close()

            if (c != '+'):
                self.ResetConfig()

                dialog = wx.MessageDialog(self.panel, "Logger communication timeout.", caption = "Error", style = wx.OK | wx.ICON_EXCLAMATION)
                dialog.ShowModal()
                dialog.Destroy()
                return 0
            else:
                self.UpdateConfig(chars)
                return ser     
                    
    def COMSelUpdated(self, selection):
        self.statusbar.SetStatusText(self.ports[selection], 0)
        self.port = self.ports[selection]

    def ResetConfig(self):
        self.D = 0
        self.M = 0
        self.S = 0
        self.A = 0
        self.N = 0
        self.T = 0
        self.dataNum = 0
        self.connected = False

        #self.statusbar.SetStatusText("Port Not Set", 0)
        self.statusbar.SetStatusText("Not Connected", 1)
        self.statusbar.SetStatusText("", 2)

    def UpdateConfig(self, config):
        d = config.index('D')
        m = config.index('M')
        s = config.index('S')
        a = config.index('A')
        n = config.index('N')
        t = config.index('T')
        dataNumIndex = config.index('#')

        self.D = int(''.join(config[d + 1:m]))
        self.M = int(''.join(config[m + 1:s]))
        self.S = int(''.join(config[s + 1:a]))
        self.A = int(''.join(config[a + 1:n]))
        self.N = int(''.join(config[n + 1:t]))
        self.T = int(''.join(config[t + 1:dataNumIndex]))
        self.dataNum = int(''.join(config[dataNumIndex + 1:-1]))

        self.deviceIDSpin.SetValue(self.D)

        if (self.M == 0):
            self.baseClockUnitsChoice.SetSelection(0)
        else:
            self.baseClockUnitsChoice.SetSelection(1)
        
        self.baseClockSpin.SetValue(self.S)
        self.activitySpin.SetValue(self.A)
        self.averageSpin.SetValue(self.N)
        self.tempSpin.SetValue(self.T)

        if (self.A == 0):
            self.activityCheck.SetValue(False)
        else:
            self.activityCheck.SetValue(True)
        if (self.N == 0):
            self.averageCheck.SetValue(False)
        else:
            self.averageCheck.SetValue(True)
        if (self.T == 0):
            self.tempCheck.SetValue(False)
        else:
            self.tempCheck.SetValue(True)
            
        self.OnActivityCheck(None)
        self.OnAverageCheck(None)
        self.OnTempCheck(None)

        if (self.dataNum == 0):
            self.statusbar.SetStatusText("Device Cleared", 2)
        else:
            self.statusbar.SetStatusText("Device Not Cleared", 2)

        self.UpdateInfo()

    def OnConnectButton(self, event):
        ser = self.GetCOMPort()

        print("1")
        if ser:
            ser.open()
            print("2")
            ser.write(b'+')
            print("3")
            
            c = ""

            chars = []

            i = 0

            print("4")
    
            for i in range(40):
                c = ser.read().decode('utf-8')
                chars.append(c)

                print(c)

                if (c == '+'):
                    break

            print("5")

            ser.close()

            if (c != '+'):
                self.ResetConfig()
                dialog = wx.MessageDialog(self.panel, "Logger communication timeout.", caption = "Error", style = wx.OK | wx.ICON_EXCLAMATION)
                dialog.ShowModal()
                dialog.Destroy()
            else:     
                self.UpdateConfig(chars)
                self.statusbar.SetStatusText("Connected", 1)

                self.connected = True

                dialog = wx.MessageDialog(self.panel, "Connected!", caption = "Success", style = wx.OK)
                dialog.ShowModal()
                dialog.Destroy()
       
    def OnDownloadButton(self, event):
        ser = self.GetDatalogger()

        if (ser and self.GetDeviceConnected()):

            dialog = wx.FileDialog(
                self, message = "Save file as ...", defaultDir = os.getcwd(),wildcard="TXT files (*.txt)|*.txt|CSV files (*.csv)|*.csv",
                defaultFile = "", style = wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)

            if dialog.ShowModal() == wx.ID_OK:
                path = dialog.GetPath()
            
                ser.open()
                ser.write(b'W')

                c = ""

                while (not(ser.in_waiting)):
                    pass

                file = open(path, 'w')

                tempCount = 0
                actCount = 0

                if (self.N == 0):
                    activityWait = self.A
                else:
                    activityWait = self.A * self.N

                tempWait = self.T

                i = 0
                time = 0

                day = 0
                hour = 0
                minute = 0
                second = 0

                increment = 0
                
                if (self.M == 0):
                    increment = self.S
                else:
                    increment = self.S * 60

                writtenLine = False

                disableAll = wx.WindowDisabler()

                #wait = wx.BusyInfo("Downloading data, this may take a few minutes...")

                file.write("DAY,HOUR,MINUTE,SECOND,ACTIVITY,TEMPERATURE\n")

                dataToWrite = ""
                gotData = 0
                
                while True:

                    self.statusbar.SetStatusText(str(round(i / 1000)) + " kilobytes read.", 2)

                    if (i % 500 == 0):
                        wx.GetApp().Yield()
                        
                    tempCount += 1
                    actCount += 1
                    
                    second += increment

                    if (second >= 60):
                        minute += second // 60
                        second = second % 60
                    if (minute >= 60):
                        hour += minute // 60
                        minute = minute % 60
                    if (hour >= 24):
                        day += hour // 24
                        hour = hour % 24

                    if ((actCount == activityWait) or (tempCount == tempWait)):

                        dataToWrite += (str(day) + ',' +
                                       str(hour) + ',' +
                                       str(minute) + ',' +
                                       str(second) + ',')
                        
                    if (actCount == activityWait):

                        while (not(ser.in_waiting)):
                            pass
                        
                        num = int.from_bytes(ser.read(), byteorder='big')

                        #print(num)

                        if (num == 255):
                            break

                        dataToWrite += str(num)
                        
                        i += 1
                        actCount = 0

                        gotData = 1

                    dataToWrite += ','

                    if (tempCount == tempWait):
                        
                        while (not(ser.in_waiting)):
                            pass
                        
                        num1 = int.from_bytes(ser.read(), byteorder='big')
                        #print(num1)

                        if (num1 == 255):
                            break

                        while (not(ser.in_waiting)):
                            pass
                        
                        num2 = int.from_bytes(ser.read(), byteorder='big')
                        #print(num2)
                        
                        if (num2 == 255):
                            break

                        dataToWrite += str(num1 << 8 | num2)
                        i += 2
                        tempCount = 0

                        gotData = 1

                    dataToWrite += '\n'

                    if (gotData == 1):
                        file.write(dataToWrite)

                    gotData = 0
                    dataToWrite = ""

                file.close()

                ser.close()

                #del wait
                del disableAll

                self.GetDatalogger()

                dialog = wx.MessageDialog(self.panel, "Successfully read " + str(i) + " byte(s).", caption = "Success", style = wx.OK)
                dialog.ShowModal()
                dialog.Destroy()
            
    def OnEraseButton(self, event):
        ser = self.GetDatalogger()

        if (ser and self.GetDeviceConnected()):
            dialog = wx.MessageDialog(self.panel, "Are you sure?", caption = "Confirm Datalogger Erase", style = wx.YES_NO | wx.ICON_EXCLAMATION)

            if (dialog.ShowModal() == wx.ID_YES):

                ser.open()
                ser.write(b'XX')

                disableAll = wx.WindowDisabler()
                wait = wx.BusyInfo("Erasing device, this may take a few minutes...")

                while True:
                    wx.GetApp().Yield()

                    c = ser.read().decode('utf-8')

                    if (c == '!'):
                        break

                ser.close()

                del wait
                del disableAll

                self.GetDatalogger()

                dialog = wx.MessageDialog(self.panel, "Data Erased!", caption = "Success", style = wx.OK)
                dialog.ShowModal()
                dialog.Destroy()

app = wx.App()
Frame("LoggerMate Datalogger Config Utility").Show(True)
app.MainLoop()
